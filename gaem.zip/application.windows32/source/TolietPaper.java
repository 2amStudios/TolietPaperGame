import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import shiffman.box2d.*; 
import org.jbox2d.common.*; 
import org.jbox2d.dynamics.joints.*; 
import org.jbox2d.collision.shapes.*; 
import org.jbox2d.collision.shapes.Shape; 
import org.jbox2d.common.*; 
import org.jbox2d.dynamics.*; 
import org.jbox2d.dynamics.contacts.*; 
import beads.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class TolietPaper extends PApplet {










//0 - play
int gamestate = -1;


//sprites
PImage gun;
PImage van;
PImage road;
PImage bullet;
PImage player;
PImage enemy;
PImage aura;
PImage car;
PImage bike;
PImage explode;
PImage explode2;
PImage icon;
PImage wasted;

PImage title;
PImage tut;
PImage titletext;
PImage winscreen;
//shader
PShader shader;
PImage pallette;
PImage noise;

PGraphics mainCanvas;
//audio
Sample bgMusic= null;
float trans = 0;
PFont font;


public void settings(){
  size(displayWidth,displayHeight-50,P2D);
}
public void setup(){
  
  box2d = new Box2DProcessing(this);
  box2d.createWorld();
  box2d.setGravity(0,0);
  box2d.listenForCollisions();
  surface.setResizable(true);

  t = new Truck(100,100,radians(30));
  gameobjects.add(t);
  initAudio();
  title = loadImage("title.png");
  tut = loadImage("tut.png");
  titletext = loadImage("titletext.png");
  gun = loadImage("gunsheet.png");
  van= loadImage("truck.png");
  road = loadImage("path.png");
  bullet= loadImage("bullet.png");
  player= loadImage("player.png");
  enemy= loadImage("enemy.png");
  noise = loadImage("NoiseTex.png");
  pallette = loadImage("pal.png");
  aura = loadImage("aura.png");
  car = loadImage("car.png");
  bike = loadImage("bike.png");
  icon = loadImage("icons.png");
  wasted = loadImage("wasted.png");
  explode= loadImage("explode.png");
  explode2= loadImage("explode2.png");
  winscreen=loadImage("winscreen.png");
  surface.setTitle("Rolled out");
  font=(createFont("font.ttf",64));
  mainCanvas = createGraphics(displayWidth,displayHeight,P2D);
  ((PGraphicsOpenGL)this.g).textureSampling(2);
  testpath = new Path();
  testpath.path.add(new PathSegment(new Vec2(0,-1000),new Vec2()));
  testpath.path.add(new PathSegment(new Vec2(),new Vec2(width*4,300)));
  testpath.path.add(new PathSegment(new Vec2(width*4,300),new Vec2(width*8,0)));
  float tpx = width*8; float tpy = 0;
  for(int i = 0;i<120;i++){
    
    ang+=random(-1,1);
    ang = constrain(ang,-PI,PI);
    float dis = random(800,3000);
    float dx = cos(ang)*dis;
    float dy = sin(ang)*dis;
    testpath.path.add(new PathSegment(new Vec2(tpx,tpy),new Vec2(tpx+dx,tpy+dy)));
    tpx+=dx;
    tpy+=dy;
  }
  
  t.pathseg=1;
  t.mode=1;
  
  for(int i =0;i<5;i++){
    paths.add(new PathTile(i,testpath));
  }
  
  shader = loadShader("shader.glsl");
  shader.init();
}


float ang=0;
ArrayList<PathTile> paths = new ArrayList();
//game objects
ArrayList<GameObject> gameobjects = new ArrayList();
ArrayList<Particle> pfx = new ArrayList();
Truck t;
Path testpath;

public void spawnAtPathPoint(int type, int node, float spread){
  if(node<0||node>testpath.path.size()-1){
    return;
  }
  PhysicsGameObject pg;
  PathSegment ps = testpath.path.get(node);
  switch(type){
    case 1:
      pg = new Bike(ps.start.x+random(-spread,spread),ps.start.y+random(-spread,spread),radians(random(180)));
      break;
    case 2:
      pg = new Car(ps.start.x+random(-spread,spread),ps.start.y+random(-spread,spread),radians(random(180)));
      break;  
    default:
      pg = new PersonOnFoot(ps.start.x+random(-spread,spread),ps.start.y+random(-spread,spread),radians(random(180)));
  }
  pg.pathseg = node;
  pg.mode=1;
  
  gameobjects.add(pg);
}


float cmx,cmy;

float gmx,gmy;
float scale = 1;


float animatetick =0;
//title
float titletextscale = 1.5f;

float time = 0;

public void draw(){
  animatetick++;
  trans++;
  
  updateAudio();
  switch(gamestate){
    case -2:
    background(42);
      image(tut,width/2 - tut.width/2,height/2 - tut.height/2);
      if(mousePressed&&trans>30){
        gamestate = 0;
        trans=0;
      }
    break;
    case -1:
      background(42);
      image(title,width/2 - title.width/2,height/2 - title.height/2);
      pushMatrix();
      translate(width/2,height/2);
      rotate(sin(animatetick*0.01f)*0.03f);
      scale(titletextscale);
      titletextscale+=(0.5f-titletextscale)*0.1f;
      image(titletext,- titletext.width/2, - titletext.height/2);
      popMatrix();
      if(mousePressed){
        gamestate =-2;
        trans=0;
      }
    break;
    case 0:
    time+=1f/60f;
      if(bgMusic==null){
        bgMusic = playSample("toilet_truck.mp3",true,0.5f);
        
        //((Envelope)bgMusic.gain.getGainEnvelope()).addSegment(0,10);
      }
      for(int i = 0;i<gameobjects.size();i++){
        GameObject g = gameobjects.get(i);
        g.update();
        if(g.hp<=0){
          g.destroy();
          gameobjects.remove(i);
          i--;
        }
      }
      box2d.step();
     
      
      cmx += ((width/2*scale)-t.position.x-cmx)*0.1f;
      cmy += ((height/2*scale)-t.position.y-cmy)*0.1f;
      gmx = mouseX*scale-cmx;
      gmy = mouseY*scale-cmy;
      mainCanvas.beginDraw();
      mainCanvas.background(20);
      mainCanvas.pushMatrix();
      mainCanvas.scale(1f/scale);
      mainCanvas.translate(cmx,cmy);
      
      mainCanvas.ellipse(gmx,gmy,5,5);
      
      int highestpathnode= 0;
      for(int i = 0;i<paths.size();i++){
        PathTile g = paths.get(i);
        g.draw(0,mainCanvas);
        highestpathnode = max(highestpathnode,g.node);
        if(g.node<=t.totalpathTravelled-3){
          paths.remove(i);
          i--;
        }
      }
      if(highestpathnode<t.totalpathTravelled+3){
        paths.add(new PathTile(highestpathnode+1,testpath));
      }
      
      for(int i = 0;i<pfx.size();i++){
        Particle g = pfx.get(i);
        g.update();
        if(g.life<=0){
          pfx.remove(i);
          i--;
        }
      }
      for( Particle p: pfx){
        p.draw(mainCanvas);
      }
      
      
      mainCanvas.fill(255);
      for(GameObject g:gameobjects){
        if(g instanceof CarClimber){
        
          continue;
        }
        g.draw(mainCanvas);
      }
      
      //debug
      
      mainCanvas.popMatrix();
      
      
      
      //spawning goes here
      if(random(250)<1){
        int thing = constrain((int)random(constrain(t.totalpathTravelled*0.15f,0,3)),0,2);
        float severity = t.totalpathTravelled/60f;
        for(int i=0;i<constrain(severity*10f/(thing+1f),1,10);i++){
          spawnAtPathPoint(thing,(int)(t.totalpathTravelled+0.8f)+(random(2)>1?1:-3),100);
        }
      }
      //progress bar
      mainCanvas.fill(0,255,0);
      mainCanvas.rect(10,10,(width-100)*time/(360),20);
      mainCanvas.noFill();
      mainCanvas.stroke(0,255,0);
      mainCanvas.rect(10,10,(width-100),20);
      mainCanvas.noStroke();
      mainCanvas.fill(0,255,0);
      int iconw= icon.width/4;
      drawSprite(mainCanvas,icon,3*iconw,0,iconw,icon.height,width-80,10,iconw,icon.height);
      drawSprite(mainCanvas,icon,1*iconw,0,iconw,icon.height,10,100,iconw,icon.height);
      mainCanvas.rect(80,120,t.hp,20);
      mainCanvas.textFont(font);
      drawSprite(mainCanvas,icon,0*iconw,0,iconw,icon.height,10,190,iconw,icon.height);
      mainCanvas.text(paperammo+"",80,240);
      mainCanvas.endDraw();
      shader.set("noisetex",noise);
      shader.set("pal",pallette);
      shader.set("offset",-cmx/256,cmy/256);
      shader.set("steps",pallette.width);
      shader(shader);
      image(mainCanvas,0,0);
      
      if(time/(360)>=1){
        gamestate=1;
        animatetick = 0;
      }
    break;
    case 1:
      resetShader();
      background(animatetick);
      tint(animatetick);
      image(winscreen,width/2 - winscreen.width/2,height/2 - winscreen.height/2);
      if(animatetick>300){
        textAlign(CENTER,CENTER);
        textFont(font);
        fill(0);
        float shake = 20f/(animatetick-300);
        text("Delivered: "+paperammo+" toliet paper rolls",0+random(-shake,shake),150+random(-shake,shake),width,height);
      }
    break;
  }
  
  
  if(trans<30){
    fill(42,255-trans*9);
    rect(0,0,width,height);
  }

}
  
Box2DProcessing box2d;


public void beginContact(Contact cp) {
  // Get both fixtures
  Fixture f1 = cp.getFixtureA();
  Fixture f2 = cp.getFixtureB();
  // Get both bodies
  Body b1 = f1.getBody();
  Body b2 = f2.getBody();

  // Get our objects that reference these bodies
  Object o1 = b1.getUserData();
  Object o2 = b2.getUserData();

  if (o1 instanceof PhysicsGameObject&&o2 instanceof PhysicsGameObject) {
    PhysicsGameObject p1 = (PhysicsGameObject)o1;
    PhysicsGameObject p2 = (PhysicsGameObject)o2;
    CollisionEvent c = new CollisionEvent(p1, p2, box2d.vectorWorldToPixels(b1.getLinearVelocity()), box2d.vectorWorldToPixels(b2.getLinearVelocity()));
    p1.collisions.add(c);
    p2.collisions.add(c);
  }
}

// Objects stop touching each other
public void endContact(Contact cp) {
}

class CollisionEvent {
  PhysicsGameObject o1;
  PhysicsGameObject o2;
  Vec2 pvel1;
  Vec2 pvel2;

  CollisionEvent(PhysicsGameObject o1, PhysicsGameObject o2, Vec2 pvel1, Vec2 pvel2) {
    this.o1=o1;
    this.o2=o2;
    this.pvel1=pvel1;
    this.pvel2=pvel2;
  }
}


abstract class GameObject {
  PVector position;
  float hp=1;
  int faction;

  public boolean isIn(Vec2 pos) {
    return false;
  }

  float lastdamage = 0;
  public void damage(float damage) {
    lastdamage = 0;
    hp-=damage;
  }
  public abstract void destroy();
  public abstract void update();
  public abstract void draw(PGraphics pg);
}
class CarClimber extends GameObject {
  PhysicsGameObject current;
  
  PhysicsGameObject target=null;
  
  float jumpcooldown = 0;
  float jumpani = 0; 

  CarClimber(PhysicsGameObject attached) {
    this.current = attached;
    position = new PVector();
    hp=4;
  }
  //for now well make sure everyone makes it
  public void jump(PhysicsGameObject newobject) {
    if (newobject.addClimber(this)) {
      current.climbers.remove(this);
      current = newobject;
      jumpcooldown=0;
      target = null;
    }
  }
  
  public void preparejump(PhysicsGameObject newobject) {
    if (jumpcooldown>40) {
      target = newobject;
    }
  }
  
  public PVector getAbsolutePos(){
     return position.copy().rotate(-current.angle).add(current.position);
  }
  Vec2 jumptarget;
  float angle = 0;
  float speed;
  int stealcooldown = 0;
  public void update() {
    lastdamage++;
    jumpcooldown++;
    speed=0;
    if(target!=null){
      PVector abspos =  getAbsolutePos();
      Vec2 jumptargetrel = target.constrainPoint(target.transform(abspos));
      jumptarget = current.transform(target.getAbsolutePos(new PVector(jumptargetrel.x,jumptargetrel.y)));
      float dist = dist(jumptarget.x,jumptarget.y,position.x,position.y);
      if(dist<10){
        jump(target);
      }else if(dist>300){
        target = null;
      }
      Vec2 moveto = current.constrainPoint(jumptarget);
      angle = atan2(moveto.y-position.y,moveto.x-position.x);
      Vec2 vel = new Vec2(constrain((moveto.x-position.x)*0.1f,-2,2),constrain((moveto.y-position.y)*0.1f,-2,2));
      position.x += vel.x;
      position.y += vel.y;
      speed = vel.length();
    }
    if(current==t){
      Vec2 moveto = new Vec2(0,-60);
      float dist = dist(moveto.x,moveto.y,position.x,position.y);
      if(dist>20){
        angle = atan2(moveto.y-position.y,moveto.x-position.x);
        Vec2 vel = new Vec2(constrain((moveto.x-position.x)*0.01f,-2,2),constrain((moveto.y-position.y)*0.01f,-2,2));
        position.x += vel.x;
        position.y += vel.y;
        speed = vel.length();
      }else{
        //steal
        if(stealcooldown>100){
          t.laststeal=0;
          paperammo-=30;
          stealcooldown=0;
          t.hp-=5;
        }
        stealcooldown++;
      }
    }
    if (current==null) {
      hp=0;
    }
    
  }
  public boolean isIn(Vec2 pos) {
    if (current!=null) {
      Vec2 apos = current.transform(pos);
      return dist(apos.x, apos.y, position.x, position.y)<20;
    }
    return false;
  }
  int frame = 0;
  public void draw(PGraphics pg) {
    frame++;
    frame= frame%36;
    int aframe = frame/6;
    int speedlevel = (int)constrain(speed,0,3);
    pg.fill(200+lastdamage);
    pg.stroke(0);
    pg.pushMatrix();
    pg.translate(position.x, position.y);
    pg.rotate(angle);
    drawSprite(pg,enemy,aframe*30,40*speedlevel,30,40,-15,-20,30,40);
    pg.popMatrix();
    pg.fill(255);
  }
  public void destroy() {
    PVector pos = getAbsolutePos();
    if (current!=null) {
      current.climbers.remove(this);
    }
    playSample("splat.wav",false,0.2f);
    pfx.add(new StaticParticle(wasted,pos.x, pos.y));
  }
}
class Bullet extends GameObject {
  float vx, vy;
  float vangle;

  float drag = 1;

  Bullet(float x, float y, float ang) {
    position = new PVector(x, y);
    vx = sin(ang);
    vy=cos(ang);
  }
  Bullet(float x, float y, float vx, float vy) {
    position = new PVector(x, y);
    this.vx = vx;
    this.vy= vy;
  }
  float life=0;
  public void update() {
    position.x+=vx;
    position.y+=vy;
    vangle =  atan2(vy, vx);
    vx*=drag;
    vy*=drag;
    hp-=0.01f;
    Vec2 pos = new Vec2(position.x, position.y);
    for (GameObject g : gameobjects) {
      if (g.isIn(pos)) {
        hp=0;
        g.damage(1);
        pfx.add(new StaticAnimatedParticle(explode2,position.x, position.y,false,12));
        if (g instanceof Car) {
          ((Car)g).speed *=0.9f;
        }
        break;
      }
    }
    life++;
    
  }

  public void draw(PGraphics pg) {
    pg.pushMatrix();
    pg.translate(position.x, position.y);
    pg.rotate(vangle+PI/2 + life*0.1f);
    pg.fill(0,255,0);
    pg.image(bullet,-bullet.width/2,-bullet.height/2,bullet.width,bullet.height);
    pg.popMatrix();
  }
  public void destroy() {
  }
}

abstract class PhysicsGameObject extends GameObject {
  Body body;
  PVector position;
  float angle;
  int climbcapacity = 0;
  ArrayList<CarClimber> climbers = new ArrayList();
  public void spawnClimber() {
    if (climbers.size()<climbcapacity) {
      CarClimber c = new CarClimber(this);
      c.position.x= random(-10, 10);
      c.position.y= random(-10, 10);
      climbers.add(c);
      gameobjects.add(c);
    }
  }
  public void spawnClimberFrom(Vec2 abspos) {
    if (climbers.size()<climbcapacity) {
      CarClimber c = new CarClimber(this);
      Vec2 p = constrainPoint(transform(abspos));
      c.position.x= p.x;
      c.position.y= p.y;
      climbers.add(c);
      gameobjects.add(c);
    }
  }
  public Vec2 constrainPoint(Vec2 rp){
    return rp;
  
  }
  public PVector getAbsolutePos(PVector position){
     return position.copy().rotate(-angle).add(this.position);
  }
  
  public boolean addClimber(CarClimber c) {
    if (climbers.size()<climbcapacity) {
      Vec2 p = constrainPoint(transform(c.getAbsolutePos()));
      c.position.x= p.x;
      c.position.y= p.y;
      climbers.add(c);
      return true;
    }
    return false;
  }

  ArrayList<CollisionEvent> collisions = new ArrayList();
  public void destroy() {
    killBody();
  }
  public void killBody() {
    box2d.destroyBody(body);
  }
  public abstract void update();
  public abstract void draw(PGraphics pg);
  public abstract void makeBody();

  public void updatePos() {
    Vec2 pos = box2d.getBodyPixelCoord(body);
    position.x = pos.x;
    position.y= pos.y;
    // Get its angle of rotation
    angle = (body.getAngle()%(2*PI)+(2*PI))%(2*PI);
    lastdamage++;
  }

  public Vec2 transform(Vec2 pos) {
    Vec2 oh = pos.sub(new Vec2(position.x, position.y));
    PVector p = new PVector(oh.x, oh.y);
    p.rotate(angle);
    return new Vec2(p.x, p.y);
  }


  public Vec2 transform(PVector pos) {
    PVector p = PVector.sub(pos,position);
    p.rotate(angle);
    return new Vec2(p.x, p.y);
  }


  public void makeRectBody(Vec2 center, float w_, float h_, float density, float friction, float res) {
    // Define a polygon (this is what we use for a rectangle)
    PolygonShape sd = new PolygonShape();
    float box2dW = box2d.scalarPixelsToWorld(w_/2);
    float box2dH = box2d.scalarPixelsToWorld(h_/2);
    sd.setAsBox(box2dW, box2dH);

    // Define a fixture
    FixtureDef fd = new FixtureDef();
    fd.shape = sd;
    // Parameters that affect physics
    fd.density = density;
    fd.friction = friction;
    fd.restitution = res;



    // Define the body and make it from the shape
    BodyDef bd = new BodyDef();
    bd.type = BodyType.DYNAMIC;
    bd.angularDamping = 10.0f;
    bd.linearDamping = 0.2f;
    bd.position.set(box2d.coordPixelsToWorld(center));

    body = box2d.createBody(bd);
    body.createFixture(fd);
  }


  public void applyForce(Vec2 force, PVector rpos) {
    //rpos.rotate(-angle);
    body.applyForce(force, body.getWorldPoint(box2d.vectorPixelsToWorld(rpos)));
  }

  public Vec2 getForwardDir() {
    //rpos.rotate(-angle);
    return new Vec2(sin(angle), cos(angle));
  }


  public void applyVehicleDrag(float mul) {
    Vec2 fp = getForwardDir();
    Vec2 fpp = new Vec2(fp.y, fp.x);
    float velt = Vec2.dot(body.getLinearVelocity(), fpp);
    body.applyForce(fpp.mul(-velt*body.getMass()*mul), body.getWorldCenter());
  }
  public void pushForwards(float force) {
    applyForce(box2d.vectorPixelsToWorld(getForwardDir().mul(force*body.getMass())), new PVector(0, 0));
  }

  public void rotateTowards(float x, float y, float force) {
    Vec2 dir = new Vec2(x-position.x, -(y-position.y));
    float ang  =targetAng(angle, (atan2(dir.y, dir.x) +PI/2+ (2*PI))%(2*PI));
    body.applyAngularImpulse((ang-angle)*force*body.getMass());
  }
  public void rotateTowards(float tang, float force) {

    float ang  =targetAng(angle, (tang+ (2*PI))%(2*PI));
    body.applyAngularImpulse((ang-angle)*force*body.getMass());
  }
  public void rotateTowardsDirection(float x, float y, float force) {
    Vec2 dir = new Vec2(x, -(y));
    float ang  =targetAng(angle, (atan2(dir.y, dir.x) +PI/2+ (2*PI))%(2*PI));
    body.applyAngularImpulse((ang-angle)*force*body.getMass());
  }

  public float distanceToTruck() {
    return dist(position.x, position.y, t.position.x, t.position.y);
  }

  //testing
  int pathseg = 0;
  //finding start 0,  pathing -1 
  int mode=0;
  float palongness=1;

  float totalpathTravelled=0;

  public void followPath(Path p, float speedfactor) {
    float calongness = p.path.get(pathseg).alongness(new Vec2(position.x, position.y));
    totalpathTravelled = pathseg+constrain(calongness, 0, 1);
    Vec2 posvec = new Vec2(position.x, position.y);
    PathSegment ps = p.path.get(pathseg);
    float vel = (body.getLinearVelocity()).length()*0.1f;
    switch(mode) {
    case 0:
      Vec2 startpos = ps.start;
      rotateTowards(startpos.x, startpos.y, constrain(vel, 0, 3.5f));
      if (sign(calongness)!=sign(palongness) || distsqrd(startpos.x, startpos.y, position.x, position.y)<180*180) {
        mode = 1;
      }
      pushForwards(40*speedfactor);
      break;
    case 1:

      rotateTowards(ps.angle, constrain(vel, 0, 3.5f));
      if (ps.distance(posvec)>10 && atan2(sin(ps.angle-angle), cos(ps.angle-angle))<PI/2) {
        rotateTowards(ps.angle+radians(constrain((ps.whichside(posvec)-1.5f)*ps.distance(posvec)*0.4f, -65, 65)), constrain(vel, 0, 3.5f));
      }
      if (calongness>1) {
        pathseg++;
        pathseg = pathseg%testpath.path.size();

        PathSegment ps2 = p.path.get(pathseg);
        if (ps2.alongness(posvec)>0) {
          mode=1;
        } else {
          mode=0;
        }
      }
      pushForwards(100*speedfactor);
      break;
    }
    palongness = calongness;
  }
}

class PathSegment {
  Vec2 start, finish;
  float angle;
  float length;
  Vec2 normdir;
  
  PathSegment(Vec2 start, Vec2 finish) {
    this.start=start;
    this.finish = finish;
    Vec2 diff = finish.sub(start);
    normdir = new Vec2(diff);
    normdir.normalize();
    angle = ((atan2(-diff.y, diff.x)+PI/2+ (2*PI))%(2*PI));
    length = dist(start.x,start.y,finish.x,finish.y);
  }

  public float alongness(Vec2 pos) {
    return Vec2.dot(finish.sub(start), pos.sub(start))/(sqrd(start.x-finish.x)+sqrd(start.y-finish.y));
  }
  public float distance(Vec2 pos) {
    return finish.sub(start).mul(alongness(pos)).sub(pos.sub(start)).length();
  }
  public int whichside(Vec2 pos) {
    return orientation(pos.x, pos.y, start.x, start.y, finish.x, finish.y);
  }
}

class Path {
  ArrayList<PathSegment> path = new ArrayList();
}

int paperammo = 10000;


class Truck extends PhysicsGameObject {

  Truck(float x, float y, float ang) {
    position = new PVector(x, y);
    angle = ang;
    makeBody();
    hp = 400;
    faction =1;
    body.setUserData(this);
    climbcapacity = 8;
  }

  int firetick = 0;
  float speedpenalty = 0;
  float laststeal = 100;
  public void update() {
    updatePos();
    laststeal++;
    if (mousePressed) {
      Vec2 dir = new Vec2(gmx-position.x, (gmy-position.y));
      dir.normalize();

      if (firetick>5) {
        firetick=0;
        Vec2 vel = box2d.vectorWorldToPixels(body.getLinearVelocity());
        gameobjects.add(new Bullet(position.x+dir.x*20, position.y+dir.y*20, dir.x*9+vel.x/60f, dir.y*9+vel.y/60f));
        playSample("turret.wav",false,0.2f);
        paperammo--;
      }
      
      //dir  = dir.mul(100);
      //applyForce(box2d.vectorPixelsToWorld(getForwardDir().mul(100*body.getMass())),new PVector(0,0));

      //float ang  =targetAng(angle,(atan2(dir.y,dir.x) +PI/2+ (2*PI))%(2*PI));
      //body.applyAngularImpulse(sign(ang-angle)*8000);
      //rotateTowards(gmx,gmy,18);
      //println(degrees(ang),degrees(angle),degrees(atan2(dir.y,dir.x)));
      //body.getLinearVelocity()
      //body.applyForce(dir,body.getWorldCenter().add(box2d.coordPixelsToWorld(new Vec2(50,0))));
    }
    firetick++;
    followPath(testpath, max(0, 1.0f-speedpenalty));
    applyVehicleDrag(1.0f);
    speedpenalty*=0.8f;
  }
  public void draw(PGraphics pg) {
    Vec2 dd = getForwardDir();
    pg.pushMatrix();
    float shakeam = max(0,20-laststeal);
    pg.translate(position.x+random(-shakeam), position.y+random(-shakeam));
    Vec2 dir = new Vec2(gmx-position.x, (gmy-position.y));
    pg.stroke(0);
    pg.pushMatrix();
    pg.rotate(-angle+PI);
    pg.tint(100+laststeal*4);
    pg.image(van,-van.width/2,-van.height/2,van.width,van.height);
    pg.noTint();
    pg.fill(255);
    pg.rotate(-PI);
    for (CarClimber c : climbers) {
      pg.image(aura,c.position.x-36,c.position.y-36);
    }
    for (CarClimber c : climbers) {
      c.draw(pg);
    }
    
    pg.popMatrix();
    pg.rotate(atan2(dir.y, dir.x)+PI/2);
    drawSprite(pg,gun,constrain(firetick,0,4)*(gun.width/5),0,(gun.width/5),gun.height,-40, -30, 80, 60);
    pg.rotate(PI/2);
    drawSprite(pg,player,constrain(firetick,0,4)*(player.width/6),0,(player.width/6),player.height,20-player.width/12, 5-player.height/2, player.width/6, player.height);
    pg.popMatrix();
    
    
    
  }
  public @Override
  Vec2 constrainPoint(Vec2 rp){
    return new Vec2(constrain(rp.x,-60,60),constrain(rp.y,-120,120));
  
  }
  
  public void makeBody() {
    makeRectBody(new Vec2(position.x, position.y), 120, 240, 10, 0.1f, 0.1f);
    body.setTransform(box2d.coordPixelsToWorld(new Vec2(position.x, position.y)), angle);
  }
}


class Car extends PhysicsGameObject {
  float len;
  float speed =1.0f;
  boolean ded = false;
   SpatialSample humm;
  Car(float x, float y, float ang) {
    position = new PVector(x, y);
    angle = ang;
    makeBody();
    hp = 70;
    body.setUserData(this);

    climbcapacity = 4;
    for (int i = 0; i<random(4); i++) {
      spawnClimber();
    }
  } 

  public void update() {
    if(humm==null&&!ded){
      humm = playSample("car1.wav",position.x,position.y,true);
      humm.basegain=80;
      humm.gaindist=200;
    }
    humm.x=position.x;
    humm.y=position.x;
    humm.update();
    updatePos();
    float dtt = distanceToTruck();
    if (!collisions.isEmpty()) {
      Vec2 vel = box2d.vectorWorldToPixels(body.getLinearVelocity());
      for (CollisionEvent c : collisions) {
        float sh=0;
        PhysicsGameObject other = null;
        if (c.o1==this) {
          sh  = c.pvel1.sub(vel).length()/60f;
          other=c.o2;
        } else {
          sh  = c.pvel2.sub(vel).length()/60f;
          other=c.o1;
        }
        if (sh>1) {
          damage(sh*5);
        }

        if (other.distanceToTruck()<dtt) {
          for (int i =0; i<climbers.size(); i++) {
            if (random(2)<1) {
              climbers.get(i).preparejump(other);
            }
          }
        }
      }
    }
    collisions.clear();
    if(!ded){
      followPath(testpath, constrain(t.totalpathTravelled>totalpathTravelled?2.0f:0.5f, 0, 2.0f*speed));
    }else{
      body.applyAngularImpulse(8.5f*body.getMass());
      
    }
    applyVehicleDrag(1.0f);
    if (t.totalpathTravelled-totalpathTravelled>7) {
      hp=0;
    }
  }
  public void draw(PGraphics pg) {
    //Vec2 dd = getForwardDir();
    pg.pushMatrix();
    pg.translate(position.x, position.y);
    //line(0,0,dd.x*1000,dd.y*1000);
    pg.rotate(-angle);
    pg.tint(200+min(50,lastdamage) - (ded?100:0));
    pg.image(car,-car.width/2,car.height/2,car.width,-car.height);
    //pg.rect(-45, -len/2, 90, len);
    pg.noTint();
    for (CarClimber c : climbers) {
      pg.image(aura,c.position.x-36,c.position.y-36);
    }
    for (CarClimber c : climbers) {
      c.draw(pg);
    }

    pg.popMatrix();
  }
  public @Override
    boolean isIn(Vec2 pos) {
    Vec2 tr = transform(pos);
    return tr.x>-45&&tr.y>-len/2&&tr.x<45&&tr.y<len/2;
  }
  public @Override
  Vec2 constrainPoint(Vec2 rp){
    return new Vec2(constrain(rp.x,-45,45),constrain(rp.y,-len/2,len/2));
  
  } 
  public @Override
  void damage(float damage) {
    playSample("explosion1.wav",false,0.1f);
    super.damage(damage);
    if(hp<=0){
      hp=1;
      if(!ded){
        playSample("explosion3.wav",false,0.5f);
        if(humm!=null){
          humm.player.kill();
        }
      }
      ded = true;
      pfx.add(new StaticAnimatedParticle(explode,position.x+random(-50,50), position.y+random(-50,50),false,14));
      
    }
     playSample("hitsound.wav",false,0.2f);
  }
  public void makeBody() {
    len = 120+random(50);
    makeRectBody(new Vec2(position.x, position.y), 90, len, 3, 0.1f, 0.1f);
    body.setTransform(box2d.coordPixelsToWorld(new Vec2(position.x, position.y)), angle);
  }
}


class Bike extends PhysicsGameObject {
  float len;
  boolean spawnwasted = true;
  SpatialSample humm;
  Bike(float x, float y, float ang) {
    position = new PVector(x, y);
    angle = ang;
    makeBody();
    hp = 10;
    body.setUserData(this);
    
  } 

  public void update() {
    if(humm==null){
      humm = playSample("bike1.wav",position.x,position.y,true);
      humm.basegain=50;
      humm.gaindist=100;
    }
    humm.x=position.x;
    humm.y=position.x;
    humm.update();
    updatePos();

    if (!collisions.isEmpty()) {
      Vec2 vel = box2d.vectorWorldToPixels(body.getLinearVelocity());
      for (CollisionEvent c : collisions) {
        float sh=0;
        PhysicsGameObject other = null;
        if (c.o1==this) {
          sh  = c.pvel1.sub(vel).length()/60f;
          other=c.o2;
        } else {
          sh  = c.pvel2.sub(vel).length()/60f;
          other=c.o1;
        }
        if (sh>hp*0.1f+0.5f) {
          damage(sh*2);
        }
        if (other.climbers.size()<other.climbcapacity&&hp<=0) {
          other.spawnClimberFrom(new Vec2(position.x, position.y));
          spawnwasted = false;
        }
      }
    }
    collisions.clear();
    followPath(testpath, t.totalpathTravelled>totalpathTravelled?1.5f:0.5f);
    applyVehicleDrag(1.0f);

    if (t.totalpathTravelled-totalpathTravelled>7) {
      hp=0;
    }
  }
  public void draw(PGraphics pg) {
    //Vec2 dd = getForwardDir();
    //Vec2 tt  = transform(new Vec2(50,50));
    pg.pushMatrix();
    pg.translate(position.x, position.y);
    //line(0,0,dd.x*1000,dd.y*1000);
    pg.rotate(-angle);
    pg.tint(200+lastdamage);
    pg.image(bike,-bike.width/2,-bike.height/2,bike.width,bike.height);
    drawSprite(pg,enemy,0,40*3,30,40,-15,-20,30,40);
    pg.noTint();
    pg.popMatrix();
  }

  public @Override
    boolean isIn(Vec2 pos) {
    Vec2 tr = transform(pos);
    return tr.x>-5&&tr.y>-len/2&&tr.x<5&&tr.y<len/2;
  }
  public void makeBody() {
    len = 70+random(5);
    makeRectBody(new Vec2(position.x, position.y), 10, len, 3, 0.1f, 0.1f);
    body.setTransform(box2d.coordPixelsToWorld(new Vec2(position.x, position.y)), angle);
  }
  
  public void destroy(){
    super.destroy();
    pfx.add(new StaticAnimatedParticle(explode,position.x, position.y,false,14));
    if(spawnwasted){
      pfx.add(new StaticParticle(wasted,position.x, position.y));
      println("spawned");
    }
    playSample("splat.wav",false,0.4f);
    if(humm!=null){
      humm.player.kill();
    }
  }
}

class PersonOnFoot extends PhysicsGameObject {
  float len;
  PersonOnFoot(float x, float y, float ang) {
    position = new PVector(x, y);
    angle = ang;
    makeBody();
    hp = 2;
    body.setUserData(this);
  } 
  boolean spawnwasted = true;
  public void update() {
    updatePos();

    if (!collisions.isEmpty()) {
      Vec2 vel = box2d.vectorWorldToPixels(body.getLinearVelocity());
      for (CollisionEvent c : collisions) {
        float sh=0;
        PhysicsGameObject other = null;
        if (c.o1==this) {
          sh  = c.pvel1.sub(vel).length()/60f;
          other=c.o2;
        } else {
          sh  = c.pvel2.sub(vel).length()/60f;
          other=c.o1;
        }
        if (sh>hp*0.1f+0.5f&&!(other instanceof PersonOnFoot)) {
          damage(sh);
          if (c.o1==t||c.o2==t) {
            t.speedpenalty+=0.5f/(1+t.speedpenalty*5.0f);
          }
        }
        if (other.climbers.size()<other.climbcapacity&&hp<=0&&random(1)<0.8f) {
          other.spawnClimberFrom(new Vec2(position.x, position.y));
          spawnwasted = false;
        }
        
      }
    }
    collisions.clear();
    followPath(testpath, t.totalpathTravelled>totalpathTravelled?1.5f:0.5f);
    applyVehicleDrag(2.0f);

    if (t.totalpathTravelled-totalpathTravelled>7) {
      hp=0;
    }
  }
  int frame = 0;
  public void draw(PGraphics pg) {
    //Vec2 dd = getForwardDir();
    //Vec2 tt  = transform(new Vec2(50,50));
    frame++;
    int aframe = (frame/6)%6;
    pg.pushMatrix();
    pg.translate(position.x, position.y);
    //line(0,0,dd.x*1000,dd.y*1000);
    pg.rotate(-angle+PI/2);
    pg.tint(200+lastdamage);
    drawSprite(pg,enemy,aframe*30,40*3,30,40,-15,-20,30,40);
    pg.noTint();
    pg.popMatrix();
  }
   public @Override
  void destroy(){
    super.destroy();
    if(spawnwasted){
      pfx.add(new StaticParticle(wasted,position.x, position.y));
      println("spawned");
    }
    playSample("splat.wav",false,0.4f);
  }
  
  public @Override
    boolean isIn(Vec2 pos) {
    Vec2 tr = transform(pos);
    return tr.x>-20&&tr.y>-len/2&&tr.x<20&&tr.y<len/2;
  }
  public void makeBody() {
    len = 30;
    makeRectBody(new Vec2(position.x, position.y), 40, len, 3, 0.1f, 0.1f);
    body.setTransform(box2d.coordPixelsToWorld(new Vec2(position.x, position.y)), angle);
  }
}
class TerrainTile{
  PImage texture;
  float x,y;
  
  
}

class PathTile{
  PathSegment prev;
  PathSegment after;
  PathSegment c;
  int node;
  
  PathTile(int node, Path p){
    this.node=node;
    if(node>0){
      prev = p.path.get(node-1);
    }
    if(node<p.path.size()-1){
      after = p.path.get(node+1);
    }
    c = p.path.get(node);
    
  }
  
  
  public void draw(float start,PGraphics pg){
    float startcutoff = 0;
    float endcutoff = 0;
    if(prev!=null){
       float cosa = sqrt((Vec2.dot(prev.normdir,c.normdir)+1)*0.5f);
       float tana = sqrt(1-cosa*cosa)/cosa;
       startcutoff = tana*road.width/2;
    }
    if(after!=null){
       float cosa = sqrt((Vec2.dot(after.normdir,c.normdir)+1)*0.5f);
       float tana = sqrt(1-cosa*cosa)/cosa;
       endcutoff = tana*road.width/2;
    }
    float px=c.start.x,py=c.start.y;
    px+=startcutoff*c.normdir.x;
    py+=startcutoff*c.normdir.y;
    
    float tx = c.normdir.y*road.width/2,ty= -c.normdir.x*road.width/2;
    
    pg.beginShape(TRIANGLES);
    pg.texture(road);
   
      if(prev!=null){
         float ptx = ((prev.normdir.y*road.width/2 )+ tx)/2,pty= ((-prev.normdir.x*road.width/2)+ty)/2;
        int direction = orientation(prev.start.x,prev.start.y,c.start.x,c.start.y,c.finish.x,c.finish.y);
        pg.vertex(px  - tx,  py - ty,road.width,road.height);
        pg.vertex(px  + tx,  py + ty,0,road.height);
        //turning right
        
        if(direction==1){
          pg.vertex(c.start.x  - ptx,  c.start.y - pty,road.width,road.height);
        }
        else if(direction==2){
          pg.vertex(c.start.x  + ptx,  c.start.y + pty,0,road.height);
        }
      }
      
      if(after!=null){
         float atx = ((after.normdir.y*road.width/2 )+ tx)/2,aty= ((-after.normdir.x*road.width/2)+ty)/2;
        float alen = (c.length-endcutoff-startcutoff);
        int direction = orientation(c.start.x,c.start.y,c.finish.x,c.finish.y,after.finish.x,after.finish.y);
        pg.vertex(px +c.normdir.x*alen - tx,  py +c.normdir.y*alen - ty,road.width,0);
        pg.vertex(px +c.normdir.x*alen + tx,  py +c.normdir.y*alen + ty,0,0);
        //turning right
        if(direction==1){
          pg.vertex(c.finish.x  - atx,  c.finish.y - aty,road.width,road.height);
        }
        else if(direction==2){
          pg.vertex(c.finish.x  + atx,  c.finish.y + aty,0,road.height);
        }
      }
      
    pg.endShape();
    pg.beginShape(QUADS);
    pg.texture(road);
    for(float pc = startcutoff;pc<c.length-endcutoff;pc+=road.height){
      
      float maximal  = min((c.length-endcutoff)-pc,road.height);
      
      
      pg.vertex(px + maximal*c.normdir.x + tx,  py + maximal*c.normdir.y+ty,0,0);
      pg.vertex(px + maximal*c.normdir.x - tx,  py + maximal*c.normdir.y-ty,road.width,0);
      pg.vertex(px  - tx,  py - ty,road.width,maximal);
      pg.vertex(px  + tx,  py + ty,0,maximal);
      
      px+=road.height*c.normdir.x;
      py+=road.height*c.normdir.y;
    }
    pg.endShape();
    
  }
  
  
  
}



AudioContext ac;
PeakDetector od;
ArrayList<Sample> sounds = new ArrayList();

public void initAudio(){
  ac = new AudioContext();
  ac.start();
  ac.runNonRealTime();
  
  //and begin
}

class Sample{
  Panner pan;
  Gain gain;
  SamplePlayer player;
  OnePoleFilter opf;
  Envelope speedControl;
   String s;
  
  Sample(String name ,boolean loops){
    File f = dataFile("audio\\"+name);
    println(name);
    //gain.;
     player = new SamplePlayer(ac, SampleManager.sample(f.getAbsolutePath()));
     //float dist = dist(x,y,cmx+width/2f,cmy+height/2f);
     gain = new Gain(ac, 2, 0.5f);
     opf = new OnePoleFilter(ac, 10000);
    // println(1f/(1f+0.01*dist),2.0*(x/width-0.5));
     pan = new Panner(ac,0.0f);
     
     opf.addInput(player);
     gain.addInput(opf);
     pan.addInput(gain);
     player.start();
     
     ac.out.addInput(pan);
     speedControl =  new Envelope(ac, 1);
     player.setRate(speedControl);
     if(loops){
       player.setLoopType(SamplePlayer.LoopType.LOOP_FORWARDS);
     }else{
       player.setKillOnEnd(true);
     }
  }
  Sample(){
    
  }
  public void onRemove(){
   // gain
    pan.kill();
    //gain.s
  }
}

class StereoSample extends Sample{
  
  StereoSample(String name ,boolean loops){
    super();
    this.s=name;
    File f = dataFile("audio\\"+name);
    println(name);
     beads.Sample sm = SampleManager.sample(f.getAbsolutePath());
    // println(sm.getNumChannels()+"edesseessese");
    //sm.
     player = new SamplePlayer(ac, sm);
     //float dist = dist(x,y,cmx+width/2f,cmy+height/2f);
     gain = new Gain(ac, 2, 0.5f);
     opf = new OnePoleFilter(ac, 10000);
    // println(1f/(1f+0.01*dist),2.0*(x/width-0.5));
     ///pan.;
     
     
     //opf.addInput(player);
     gain.addInput(player);
     
     player.start();
     //pan.removeAllConnections(ac.out);
     ac.out.addInput(gain);
     speedControl =  new Envelope(ac, 1);
     player.setRate(speedControl);
     if(loops){
       player.setLoopType(SamplePlayer.LoopType.LOOP_FORWARDS);
     }else{
       player.setKillOnEnd(true);
     }
  }
  public void onRemove(){
   // gain
    opf.kill();
  }
}
class SpatialSample extends Sample{
  float x,y;
  float gaindist=1;
  float basegain=1;
  
  SpatialSample(String name, float x,float y,boolean loops){
    super(name,loops);
    File f = dataFile(name);
    this.x=x;
    this.y=y;
    update();
     //player.
  }
  
  public boolean isEnd(){ 
    return player.isDeleted();
  }
  
  public void update(){
    float dist = dist(x,y,-cmx+width/2f,-cmy+height/2f);
    gain.setGain(basegain/(gaindist+0.003f*dist));
    opf.setFrequency(10f/(0.0005f*(100+dist)));
    pan.setPos(2.0f*(x/width-0.5f));
  }
}
public void updateAudio(){
  for(int i = 0;i<sounds.size();i++){
    Sample s = sounds.get(i);
    if(s.player.isDeleted()){
      sounds.get(i).onRemove();
      sounds.remove(i);
      i--;
    }
  }
  //println();
}

public SpatialSample playSample(String name,float x,float y,boolean loop){
  //SamplePlaye
  SpatialSample ss = new SpatialSample(name,x,y,loop);
  sounds.add(ss);
  return ss;
}
public Sample playSample(String name,boolean loop){
  //SamplePlaye
  Sample s = new Sample(name,loop);
  sounds.add(s);
  return s;
}
public Sample playSample(String name,boolean loop,float gain){
  //SamplePlaye
  Sample s = new Sample(name,loop);
  s.gain.setGain(gain);
  sounds.add(s);
  return s;
}
public Sample playSample(String name,boolean loop,float gain,float speedOffset){
  //SamplePlaye
  Sample s = new Sample(name,loop);
  s.gain.setGain(gain);
  sounds.add(s);
  s.speedControl.setValue(1+speedOffset);
  return s;
}
public Sample playStereoSample(String name,boolean loop,float gain){
  //SamplePlaye
  Sample s = new  StereoSample(name,loop);
  s.gain.setGain(gain);
  sounds.add(s);
  return s;
}
abstract class Particle{
  PImage texture;
  float x,y;
  float vx,vy;
  float life = 1;
  
  public abstract void update();
  public abstract void draw(PGraphics pg);

}

class StaticParticle extends Particle{
   StaticParticle(PImage texture, float x,float y){
      this.texture = texture;
      this.x=x;
      this.y=y;
   }
   public void update(){
     
     if(distsqrd(x,y,t.position.x,t.position.y)>sqrd(2000)){
       life = 0;
     }
   }
   
   public void draw(PGraphics pg){
     //println("hewwo?");
     pg.image(texture,x-texture.width*0.5f,y-texture.height*0.5f);
   }
}

class StaticAnimatedParticle extends Particle{
  int frame=0, maxframe;
  boolean loops;
  int w,h;
   StaticAnimatedParticle(PImage texture, float x,float y,boolean loops, int frames){
      this.texture = texture;
      this.x=x;
      this.y=y;
      maxframe = frames;
      this.loops=loops;
      this.w = texture.width/frames;
      this.h=  texture.height;
      
   }
   public void update(){
     
     if(distsqrd(x,y,t.position.x,t.position.y)>sqrd(2000)){
       life = 0;
     }
     frame++;
     if(frame==maxframe){
       frame = 0;
       if(!loops){
         life= 0;
       }
     }
     
   }
   
   public void draw(PGraphics pg){
     //println("hewwo?");
     drawSprite(pg,texture, frame*w,0,w,h,     x-w*0.5f,y-h*0.5f,w,h);
   }
}
  public float targetAng(float oAng,float tAng){
    if(abs(tAng-oAng)<=PI){
      return tAng;
    }
    if(tAng-oAng>PI){
      return tAng-2*PI;
    }
    
    if(tAng-oAng<-PI){
      return tAng+2*PI;
    }
    return tAng;
  }
    public float sqrd(float x){
      return (x*x);
  }
  public float distsqrd(float x,float y,float x2,float y2){
      return sqrd(x-x2)+sqrd(y-y2);
  }
    // To find orientation of ordered triplet (p, q, r).
// The function returns following values
// 0 --> p, q and r are colinear
// 1 --> Clockwise
// 2 --> Counterclockwise
    public int orientation(float px,float py, float qx,float qy, float rx,float ry)
    {
        
        float val = (qy - py) * (rx - qx) -
                  (qx - px) * (ry - qy);

        if (val == 0) return 0;  // colinear
        
        return (val > 0)? 1: 2; // clock or counterclock wise
    }
    
    public float sign(float t){
      if(t==0){return 0;}
      return t/abs(t);
    }
    
    public void drawSprite(PGraphics pg,PImage currentTexture,int tx,int ty,int tw,int th,float x,float y,float w,float h){
  pg.noStroke();
  pg.beginShape(QUADS);
  pg.texture(currentTexture);
  pg.vertex(x,   y,   tx,    ty);
  pg.vertex(x+w, y,   tx+tw, ty);
  pg.vertex(x+w, y+h, tx+tw, ty+th);
  pg.vertex(x,   y+h, tx,    ty+th);
  pg.endShape();
}



  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "TolietPaper" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
